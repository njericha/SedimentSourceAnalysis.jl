#=
helpers for loading up the raw data from excel into julia
=#

using LinearAlgebra
using XLSX

filepath(s::String) = join(["rawdata/Lee et al 2021 " s ".xlsx"],"")

elements = ["Y", "Nb", "Ce", "Pr", "Nd", "Sm", "Eu_Euprime", "U", "age"]

"""
    grain_data, rock_index = read_xlsx_data(elements)

Read the excel files for the elements given and return a matrix grain_data where
- each row is data for the same grain
- each column is data for the same element
and rock_index which gives the starting row index for each rock sample.
"""
function read_xlsx_data(elements)
    # Initialize empty vectors
    ms,ns,missing_indexs,number_of_grains_per_rocks,rock_indexs,element_cols=([] for _ ∈ 1:6)

    # Extract element data from each file into a long column
    for element ∈ elements
        # Read data
        element_data = XLSX.readdata(filepath(element),"Sheet1","A2:X61")
        element_data = element_data[:,begin:2:end] # remove every other column to clear "999" columns
        m,n = size(element_data)

        # Find length of data in each column
        missing_index = [findfirst(ismissing.(col)) for col ∈ eachcol(element_data)]
        number_of_grains_per_rock = [(isnothing(i) ? m : i-1) for i ∈ missing_index]
        calc_rock_index(i::Integer) = 1 + sum(number_of_grains_per_rock[1:i-1])
        rock_index = zip(calc_rock_index.(1:n), calc_rock_index.(1:n) .+ number_of_grains_per_rock .- 1) |> collect

        # Reshape data into a long column
        element_col = vcat((col[begin:i] for (col, i) ∈ zip(eachcol(element_data), number_of_grains_per_rock))...)

        # Push all info into a vector
        push!(ms, m)
        push!(ns, n)
        push!(missing_indexs, missing_index)
        push!(number_of_grains_per_rocks, number_of_grains_per_rock)
        push!(rock_indexs, rock_index)
        push!(element_cols, element_col)
    end

    # Check all sizes and grains are equal for each element
    for v ∈ (ms, ns, missing_indexs, number_of_grains_per_rocks, rock_indexs)
        @assert allequal(v) "The list $v does not contain identical elements"
    end

    # Stack columns into a matrix
    grain_data = hcat(element_cols...)

    # Check for negative data and flip them to positive if so
    if !all(grain_data .>= 0)
        negative_indexes = findall(grain_data .< 0)
        @warn "Negative data was found in $negative_indexes, flipping values to be positive."
        grain_data[negative_indexes] .*= -1
    end

    return grain_data, rock_indexs[1]
end